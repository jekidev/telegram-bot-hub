/**
 * Device detection from user agent
 */
export function detectDevice(userAgent: string): {
  type: "iPhone" | "Android" | "Computer" | "Unknown";
  os: string;
  browser: string;
} {
  const ua = userAgent.toLowerCase();

  // iPhone detection
  if (ua.includes("iphone") || ua.includes("ipad")) {
    const browser = ua.includes("safari") ? "Safari" : ua.includes("chrome") ? "Chrome" : "Unknown";
    return {
      type: "iPhone",
      os: ua.includes("ipad") ? "iPadOS" : "iOS",
      browser,
    };
  }

  // Android detection
  if (ua.includes("android")) {
    let browser = "Unknown";
    if (ua.includes("chrome")) browser = "Chrome";
    else if (ua.includes("firefox")) browser = "Firefox";
    else if (ua.includes("samsung")) browser = "Samsung Internet";
    else if (ua.includes("opera")) browser = "Opera";

    return {
      type: "Android",
      os: "Android",
      browser,
    };
  }

  // Computer detection
  if (ua.includes("windows") || ua.includes("macintosh") || ua.includes("linux") || ua.includes("x11")) {
    let os = "Unknown";
    let browser = "Unknown";

    if (ua.includes("windows")) os = "Windows";
    else if (ua.includes("macintosh")) os = "macOS";
    else if (ua.includes("linux")) os = "Linux";

    if (ua.includes("edge")) browser = "Edge";
    else if (ua.includes("chrome")) browser = "Chrome";
    else if (ua.includes("firefox")) browser = "Firefox";
    else if (ua.includes("safari")) browser = "Safari";
    else if (ua.includes("opera")) browser = "Opera";

    return {
      type: "Computer",
      os,
      browser,
    };
  }

  return {
    type: "Unknown",
    os: "Unknown",
    browser: "Unknown",
  };
}

/**
 * Enhanced geolocation data structure
 */
export interface EnhancedGeoLocation {
  ip: string;
  country: string;
  countryCode: string;
  region: string;
  city: string;
  latitude: number | null;
  longitude: number | null;
  timezone: string;
  isp: string;
  org: string;
  asn: string;
}

/**
 * Parse IPinfo response to enhanced geolocation
 */
export function parseIPInfo(ip: string, data: any): EnhancedGeoLocation {
  const loc = data.loc ? data.loc.split(",") : [null, null];
  const [latitude, longitude] = loc;

  return {
    ip,
    country: data.country || "Unknown",
    countryCode: data.country || "XX",
    region: data.region || "Unknown",
    city: data.city || "Unknown",
    latitude: latitude ? parseFloat(latitude) : null,
    longitude: longitude ? parseFloat(longitude) : null,
    timezone: data.timezone || "Unknown",
    isp: data.org || "Unknown",
    org: data.org || "Unknown",
    asn: data.asn || "Unknown",
  };
}

/**
 * Format geolocation for Discord display
 */
export function formatGeoLocation(geo: EnhancedGeoLocation): string {
  const coords = geo.latitude && geo.longitude ? `📍 ${geo.latitude.toFixed(4)}, ${geo.longitude.toFixed(4)}` : "📍 Unknown";
  return `${geo.city}, ${geo.region}, ${geo.country} (${geo.countryCode})\n${coords}\n🌐 ${geo.timezone}\n🏢 ${geo.isp}`;
}

/**
 * Determine if IP is outside Denmark
 */
export function isOutsideDenmark(countryCode: string): boolean {
  return countryCode.toUpperCase() !== "DK";
}

/**
 * Format complete IP information for Discord
 */
export function formatIPInfo(ip: string, geo: EnhancedGeoLocation, device: any): string {
  const outsideDK = isOutsideDenmark(geo.countryCode);
  const status = outsideDK ? "🌍 OUTSIDE DENMARK" : "🇩🇰 Denmark";

  return `\`${ip}\` | ${status}\n${device.type} • ${device.os} • ${device.browser}`;
}
