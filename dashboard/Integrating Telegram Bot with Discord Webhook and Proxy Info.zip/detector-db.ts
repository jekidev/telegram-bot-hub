import { eq, and, lt, gte } from "drizzle-orm";
import { accessLogs, rateLimits } from "../drizzle/schema";
import { getDb } from "./db";

// Rate limiting constants
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
const RATE_LIMIT_MAX_REQUESTS = 10; // Max 10 requests per minute
const RATE_LIMIT_BLOCK_DURATION_MS = 15 * 60 * 1000; // Block for 15 minutes

export async function logAccess(data: {
  ip: string;
  userAgent: string;
  country?: string;
  city?: string;
  org?: string;
  threatScore: number;
  threatFlags: string[];
  isVPN: boolean;
  isProxy: boolean;
  isTor: boolean;
  discordSent: boolean;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot log access: database not available");
    return null;
  }

  try {
    const result = await db.insert(accessLogs).values({
      ip: data.ip,
      userAgent: data.userAgent,
      country: data.country,
      city: data.city,
      org: data.org,
      threatScore: data.threatScore,
      threatFlags: JSON.stringify(data.threatFlags),
      isVPN: data.isVPN ? 1 : 0,
      isProxy: data.isProxy ? 1 : 0,
      isTor: data.isTor ? 1 : 0,
      discordSent: data.discordSent ? 1 : 0,
    });

    return result;
  } catch (error) {
    console.error("[Database] Failed to log access:", error);
    return null;
  }
}

export async function checkRateLimit(ip: string): Promise<{
  allowed: boolean;
  remaining: number;
  resetAt: Date;
  isBlocked: boolean;
  blockedUntil?: Date;
}> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check rate limit: database not available");
    return {
      allowed: true,
      remaining: RATE_LIMIT_MAX_REQUESTS,
      resetAt: new Date(Date.now() + RATE_LIMIT_WINDOW_MS),
      isBlocked: false,
    };
  }

  try {
    const now = new Date();
    const windowStart = new Date(now.getTime() - RATE_LIMIT_WINDOW_MS);

    // Get existing rate limit record
    const existing = await db.select().from(rateLimits).where(eq(rateLimits.ip, ip)).limit(1);

    if (existing.length === 0) {
      // First request from this IP
      await db.insert(rateLimits).values({
        ip,
        requestCount: 1,
        isBlocked: 0,
      });

      return {
        allowed: true,
        remaining: RATE_LIMIT_MAX_REQUESTS - 1,
        resetAt: new Date(now.getTime() + RATE_LIMIT_WINDOW_MS),
        isBlocked: false,
      };
    }

    const record = existing[0];

    // Check if IP is blocked
    if (record.isBlocked) {
      if (record.blockedUntil && record.blockedUntil > now) {
        return {
          allowed: false,
          remaining: 0,
          resetAt: record.blockedUntil,
          isBlocked: true,
          blockedUntil: record.blockedUntil,
        };
      } else {
        // Unblock if block duration has passed
        await db
          .update(rateLimits)
          .set({
            isBlocked: 0,
            blockedUntil: null,
            requestCount: 1,
            lastRequest: now,
          })
          .where(eq(rateLimits.ip, ip));

        return {
          allowed: true,
          remaining: RATE_LIMIT_MAX_REQUESTS - 1,
          resetAt: new Date(now.getTime() + RATE_LIMIT_WINDOW_MS),
          isBlocked: false,
        };
      }
    }

    // Check if request is within window
    const lastRequest = record.lastRequest;
    const isWithinWindow = lastRequest && lastRequest.getTime() > windowStart.getTime();

    if (isWithinWindow) {
      const newCount = (record.requestCount || 0) + 1;

      if (newCount > RATE_LIMIT_MAX_REQUESTS) {
        // Block this IP
        const blockedUntil = new Date(now.getTime() + RATE_LIMIT_BLOCK_DURATION_MS);
        await db
          .update(rateLimits)
          .set({
            requestCount: newCount,
            isBlocked: 1,
            blockedUntil,
            lastRequest: now,
          })
          .where(eq(rateLimits.ip, ip));

        return {
          allowed: false,
          remaining: 0,
          resetAt: blockedUntil,
          isBlocked: true,
          blockedUntil,
        };
      }

      // Update count
      await db
        .update(rateLimits)
        .set({
          requestCount: newCount,
          lastRequest: now,
        })
        .where(eq(rateLimits.ip, ip));

      return {
        allowed: true,
        remaining: Math.max(0, RATE_LIMIT_MAX_REQUESTS - newCount),
        resetAt: new Date(lastRequest.getTime() + RATE_LIMIT_WINDOW_MS),
        isBlocked: false,
      };
    } else {
      // Window has passed, reset counter
      await db
        .update(rateLimits)
        .set({
          requestCount: 1,
          lastRequest: now,
        })
        .where(eq(rateLimits.ip, ip));

      return {
        allowed: true,
        remaining: RATE_LIMIT_MAX_REQUESTS - 1,
        resetAt: new Date(now.getTime() + RATE_LIMIT_WINDOW_MS),
        isBlocked: false,
      };
    }
  } catch (error) {
    console.error("[Database] Failed to check rate limit:", error);
    return {
      allowed: true,
      remaining: RATE_LIMIT_MAX_REQUESTS,
      resetAt: new Date(Date.now() + RATE_LIMIT_WINDOW_MS),
      isBlocked: false,
    };
  }
}

export async function getAccessStats(ip: string, hours: number = 24) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get stats: database not available");
    return null;
  }

  try {
    const cutoffTime = new Date(Date.now() - hours * 60 * 60 * 1000);

    const stats = await db
      .select()
      .from(accessLogs)
      .where(and(eq(accessLogs.ip, ip), gte(accessLogs.createdAt, cutoffTime)));

    return {
      totalAccess: stats.length,
      suspiciousCount: stats.filter((s) => (s.threatScore ?? 0) > 60).length,
      vpnCount: stats.filter((s) => s.isVPN).length,
      proxyCount: stats.filter((s) => s.isProxy).length,
      torCount: stats.filter((s) => s.isTor).length,
      avgThreatScore: stats.length > 0 ? Math.round(stats.reduce((sum, s) => sum + (s.threatScore ?? 0), 0) / stats.length) : 0,
    };
  } catch (error) {
    console.error("[Database] Failed to get stats:", error);
    return null;
  }
}
