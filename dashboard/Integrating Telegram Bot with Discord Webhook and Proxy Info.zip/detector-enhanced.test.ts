import { describe, expect, it, vi, beforeEach } from "vitest";
import { detectDevice, parseIPInfo, formatGeoLocation, formatIPInfo, isOutsideDenmark } from "./detector-utils";

describe("Device Detection", () => {
  it("should detect iPhone", () => {
    const ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1";
    const device = detectDevice(ua);
    expect(device.type).toBe("iPhone");
    expect(device.os).toBe("iOS");
  });

  it("should detect Android", () => {
    const ua = "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
    const device = detectDevice(ua);
    expect(device.type).toBe("Android");
    expect(device.os).toBe("Android");
  });

  it("should detect Windows Computer", () => {
    const ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    const device = detectDevice(ua);
    expect(device.type).toBe("Computer");
    expect(device.os).toBe("Windows");
  });

  it("should detect macOS Computer", () => {
    const ua = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    const device = detectDevice(ua);
    expect(device.type).toBe("Computer");
    expect(device.os).toBe("macOS");
  });

  it("should detect Linux Computer", () => {
    const ua = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    const device = detectDevice(ua);
    expect(device.type).toBe("Computer");
    expect(device.os).toBe("Linux");
  });

  it("should detect Chrome browser", () => {
    const ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    const device = detectDevice(ua);
    expect(device.browser).toBe("Chrome");
  });

  it("should detect Firefox browser", () => {
    const ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0";
    const device = detectDevice(ua);
    expect(device.browser).toBe("Firefox");
  });

  it("should detect Safari browser", () => {
    const ua = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15";
    const device = detectDevice(ua);
    expect(device.browser).toBe("Safari");
  });
});

describe("Geolocation Parsing", () => {
  it("should parse IPinfo response correctly", () => {
    const ipInfoData = {
      ip: "1.2.3.4",
      country: "US",
      region: "New York",
      city: "New York",
      loc: "40.7128,-74.0060",
      timezone: "America/New_York",
      org: "AS15169 Google LLC",
      asn: "AS15169",
    };

    const geo = parseIPInfo("1.2.3.4", ipInfoData);

    expect(geo.ip).toBe("1.2.3.4");
    expect(geo.country).toBe("US");
    expect(geo.city).toBe("New York");
    expect(geo.latitude).toBeCloseTo(40.7128, 3);
    expect(geo.longitude).toBeCloseTo(-74.006, 3);
    expect(geo.timezone).toBe("America/New_York");
  });

  it("should handle missing coordinates", () => {
    const ipInfoData = {
      ip: "1.2.3.4",
      country: "US",
      region: "New York",
      city: "New York",
      timezone: "America/New_York",
      org: "AS15169 Google LLC",
    };

    const geo = parseIPInfo("1.2.3.4", ipInfoData);

    expect(geo.latitude).toBeNull();
    expect(geo.longitude).toBeNull();
  });
});

describe("Geolocation Formatting", () => {
  it("should format geolocation with coordinates", () => {
    const geo = {
      ip: "1.2.3.4",
      country: "United States",
      countryCode: "US",
      region: "New York",
      city: "New York",
      latitude: 40.7128,
      longitude: -74.006,
      timezone: "America/New_York",
      isp: "Google LLC",
      org: "Google LLC",
      asn: "AS15169",
    };

    const formatted = formatGeoLocation(geo);

    expect(formatted).toContain("New York");
    expect(formatted).toContain("United States");
    expect(formatted).toContain("40.7128");
    expect(formatted).toContain("-74.0060");
    expect(formatted).toContain("America/New_York");
  });

  it("should format geolocation without coordinates", () => {
    const geo = {
      ip: "1.2.3.4",
      country: "Unknown",
      countryCode: "XX",
      region: "Unknown",
      city: "Unknown",
      latitude: null,
      longitude: null,
      timezone: "Unknown",
      isp: "Unknown",
      org: "Unknown",
      asn: "Unknown",
    };

    const formatted = formatGeoLocation(geo);

    expect(formatted).toContain("Unknown");
    expect(formatted).toContain("📍 Unknown");
  });
});

describe("Denmark Detection", () => {
  it("should detect Denmark", () => {
    expect(isOutsideDenmark("DK")).toBe(false);
    expect(isOutsideDenmark("dk")).toBe(false);
  });

  it("should detect outside Denmark", () => {
    expect(isOutsideDenmark("US")).toBe(true);
    expect(isOutsideDenmark("GB")).toBe(true);
    expect(isOutsideDenmark("SE")).toBe(true);
    expect(isOutsideDenmark("XX")).toBe(true);
  });
});

describe("IP Info Formatting", () => {
  it("should format IP info with device details", () => {
    const geo = {
      ip: "1.2.3.4",
      country: "United States",
      countryCode: "US",
      region: "New York",
      city: "New York",
      latitude: 40.7128,
      longitude: -74.006,
      timezone: "America/New_York",
      isp: "Google LLC",
      org: "Google LLC",
      asn: "AS15169",
    };

    const device = {
      type: "Computer",
      os: "Windows",
      browser: "Chrome",
    };

    const formatted = formatIPInfo("1.2.3.4", geo, device);

    expect(formatted).toContain("1.2.3.4");
    expect(formatted).toContain("OUTSIDE DENMARK");
    expect(formatted).toContain("Computer");
    expect(formatted).toContain("Windows");
    expect(formatted).toContain("Chrome");
  });

  it("should format IP info for Denmark", () => {
    const geo = {
      ip: "1.2.3.4",
      country: "Denmark",
      countryCode: "DK",
      region: "Copenhagen",
      city: "Copenhagen",
      latitude: 55.6761,
      longitude: 12.5683,
      timezone: "Europe/Copenhagen",
      isp: "TDC",
      org: "TDC",
      asn: "AS3292",
    };

    const device = {
      type: "iPhone",
      os: "iOS",
      browser: "Safari",
    };

    const formatted = formatIPInfo("1.2.3.4", geo, device);

    expect(formatted).toContain("🇩🇰 Denmark");
    expect(formatted).toContain("iPhone");
    expect(formatted).toContain("iOS");
  });
});
