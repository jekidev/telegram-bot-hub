import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock fetch for Discord webhook and external APIs
global.fetch = vi.fn();

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createDetectorContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "sample-user",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "x-forwarded-for": "192.168.1.1",
      },
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("detector.collectData", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should collect IP data and send to Discord webhook", async () => {
    const ctx = createDetectorContext();
    const caller = appRouter.createCaller(ctx);

    // Mock IPinfo API response
    (global.fetch as any).mockImplementation((url: string) => {
      if (url.includes("ipinfo.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              org: "AS12345 Example ISP",
              country: "US",
              city: "New York",
              region: "NY",
            }),
        });
      }
      if (url.includes("proxycheck.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              "192.168.1.1": {
                proxy: "no",
                vpn: "no",
                tor: "no",
                risk: 0,
              },
            }),
        });
      }
      if (url.includes("discord.com")) {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({}),
        });
      }
      return Promise.reject(new Error("Unknown URL"));
    });

    const result = await caller.detector.collectData({
      ip: "192.168.1.1",
      userAgent: "Mozilla/5.0",
      country: "US",
      city: "New York",
    });

    expect(result.success).toBe(true);
    expect(result.rateLimited).toBe(false);
    expect(result.discordSent).toBe(true);
    expect(result.data).toBeDefined();
    expect(result.data?.ip).toBe("192.168.1.1");
    expect(result.data?.threatScore).toBe(0);
    expect(result.data?.isVPN).toBe(false);
    expect(result.data?.isProxy).toBe(false);
    expect(result.data?.isTor).toBe(false);
  });

  it("should detect VPN and calculate threat score", async () => {
    const ctx = createDetectorContext();
    const caller = appRouter.createCaller(ctx);

    (global.fetch as any).mockImplementation((url: string) => {
      if (url.includes("ipinfo.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              org: "ProtonVPN",
              country: "CH",
              city: "Zurich",
            }),
        });
      }
      if (url.includes("proxycheck.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              "10.0.0.1": {
                proxy: "no",
                vpn: "yes",
                tor: "no",
                risk: 25,
              },
            }),
        });
      }
      if (url.includes("discord.com")) {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({}),
        });
      }
      return Promise.reject(new Error("Unknown URL"));
    });

    const result = await caller.detector.collectData({
      ip: "10.0.0.1",
      userAgent: "Mozilla/5.0",
    });

    expect(result.success).toBe(true);
    expect(result.data?.isVPN).toBe(true);
    expect(result.data?.threatScore).toBeGreaterThan(0);
    expect(result.data?.threatFlags).toContain("VPN Detected");
  });

  it("should detect Tor and assign high threat score", async () => {
    const ctx = createDetectorContext();
    const caller = appRouter.createCaller(ctx);

    (global.fetch as any).mockImplementation((url: string) => {
      if (url.includes("ipinfo.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              org: "Tor Exit Node",
              country: "DE",
              city: "Berlin",
            }),
        });
      }
      if (url.includes("proxycheck.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              "1.2.3.4": {
                proxy: "no",
                vpn: "no",
                tor: "yes",
                risk: 100,
              },
            }),
        });
      }
      if (url.includes("discord.com")) {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({}),
        });
      }
      return Promise.reject(new Error("Unknown URL"));
    });

    const result = await caller.detector.collectData({
      ip: "1.2.3.4",
      userAgent: "Mozilla/5.0",
    });

    expect(result.success).toBe(true);
    expect(result.data?.isTor).toBe(true);
    expect(result.data?.threatScore).toBeGreaterThanOrEqual(60);
    expect(result.data?.threatFlags).toContain("Tor Network");
  });

  it("should detect bot user agents", async () => {
    const ctx = createDetectorContext();
    const caller = appRouter.createCaller(ctx);

    (global.fetch as any).mockImplementation((url: string) => {
      if (url.includes("ipinfo.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              org: "Example ISP",
              country: "US",
              city: "New York",
            }),
        });
      }
      if (url.includes("proxycheck.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              "5.6.7.8": {
                proxy: "no",
                vpn: "no",
                tor: "no",
                risk: 0,
              },
            }),
        });
      }
      if (url.includes("discord.com")) {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({}),
        });
      }
      return Promise.reject(new Error("Unknown URL"));
    });

    const result = await caller.detector.collectData({
      ip: "5.6.7.8",
      userAgent: "python-requests/2.28.0",
    });

    expect(result.success).toBe(true);
    expect(result.data?.threatScore).toBeGreaterThan(0);
    expect(result.data?.threatFlags).toContain("Bot/Automation Detected");
  });

  it("should handle missing IP info gracefully", async () => {
    const ctx = createDetectorContext();
    const caller = appRouter.createCaller(ctx);

    (global.fetch as any).mockImplementation((url: string) => {
      if (url.includes("ipinfo.io")) {
        return Promise.resolve({
          ok: false,
        });
      }
      if (url.includes("proxycheck.io")) {
        return Promise.resolve({
          ok: false,
        });
      }
      if (url.includes("discord.com")) {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({}),
        });
      }
      return Promise.reject(new Error("Unknown URL"));
    });

    const result = await caller.detector.collectData({
      ip: "9.9.9.9",
      userAgent: "Mozilla/5.0",
    });

    expect(result.success).toBe(true);
    expect(result.data?.ip).toBe("9.9.9.9");
    expect(result.data?.org).toBe("Unknown");
  });


});
