import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { logAccess, getAccessStats } from "./detector-db";
import { detectDevice, parseIPInfo, formatGeoLocation, formatIPInfo, isOutsideDenmark } from "./detector-utils";

// Discord webhook URL for logging access
const DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1484714778835288094/TkX3x_UJUjeSrFJMYinh1ndS9tc_dzPfBe0Ls0XSZcs7yQMRZl84ttlYLNPpx2r5oGsz";

// IPinfo token for IP lookup
const IPINFO_TOKEN = "a2effbda331084";

interface ProxyCheckData {
  [key: string]: {
    proxy?: string;
    vpn?: string;
    tor?: string;
    risk?: number;
    asn?: string;
    provider?: string;
  };
}

async function getIPInfo(ip: string): Promise<any> {
  try {
    const response = await fetch(`https://api.ipinfo.io/${ip}?token=${IPINFO_TOKEN}`);
    if (response.ok) {
      return await response.json();
    }
  } catch (error) {
    console.error("[IPInfo] Error:", error);
  }
  return {};
}

async function checkProxy(ip: string): Promise<ProxyCheckData | null> {
  try {
    const response = await fetch(`https://proxycheck.io/v3/${ip}?vpn=1&risk=1`);
    if (response.ok) {
      return await response.json();
    }
  } catch (error) {
    console.error("[ProxyCheck] Error:", error);
  }
  return null;
}

function calculateThreatScore(
  proxyData: ProxyCheckData | null,
  userAgent: string,
  org: string
): { score: number; flags: string[] } {
  const flags: string[] = [];
  let score = 0;

  if (!proxyData) return { score, flags };

  const ipKey = Object.keys(proxyData)[0];
  if (!ipKey || !proxyData[ipKey]) return { score, flags };

  const details = proxyData[ipKey];

  // Check for VPN
  if (details.vpn === "yes") {
    flags.push("VPN Detected");
    score += 50;
  }

  // Check for Proxy
  if (details.proxy === "yes") {
    flags.push("Proxy Detected");
    score += 50;
  }

  // Check for Tor
  if (details.tor === "yes") {
    flags.push("Tor Network");
    score += 60;
  }

  // Check risk score
  if (details.risk && details.risk > 50) {
    flags.push(`High Risk (${details.risk})`);
    score += Math.min(30, details.risk / 2);
  }

  // Check user agent for bots
  const botPatterns = ["curl", "python-requests", "wget", "headlesschrome", "phantomjs", "bot", "spider", "crawler"];
  if (botPatterns.some((p) => userAgent.toLowerCase().includes(p))) {
    flags.push("Bot/Automation Detected");
    score += 40;
  }

  // Check for suspicious keywords in org
  const suspiciousKeywords = [
    "cloudflare",
    "aws",
    "amazon",
    "google cloud",
    "azure",
    "digitalocean",
    "vpn",
    "proxy",
    "hosting",
  ];
  if (suspiciousKeywords.some((kw) => org.toLowerCase().includes(kw))) {
    flags.push("Datacenter/Hosting Detected");
    score += 30;
  }

  return { score: Math.min(100, score), flags };
}

async function sendToDiscord(data: {
  ip: string;
  userAgent: string;
  device: any;
  geoLocation: any;
  threatScore: number;
  threatFlags: string[];
  timestamp: string;
  isVPN: boolean;
  isProxy: boolean;
  isTor: boolean;
  outsideDenmark: boolean;
  stats?: any;
}) {
  try {
    const isSuspicious = data.threatScore > 60 || data.outsideDenmark;

    const embed: any = {
      title: isSuspicious ? "🚨 SUSPICIOUS ACCESS" : "✅ Access Logged",
      color: isSuspicious ? 15548997 : 3447003, // Red if suspicious, blue if clean
      fields: [
        {
          name: "IP Address & Device",
          value: formatIPInfo(data.ip, data.geoLocation, data.device),
          inline: false,
        },
        {
          name: "Location Details",
          value: formatGeoLocation(data.geoLocation),
          inline: false,
        },
        {
          name: "Threat Analysis",
          value: `Score: ${data.threatScore}/100\nVPN: ${data.isVPN ? "Yes ⚠️" : "No"} | Proxy: ${data.isProxy ? "Yes ⚠️" : "No"} | Tor: ${data.isTor ? "Yes ⚠️" : "No"}`,
          inline: false,
        },
        {
          name: "Threat Flags",
          value: data.threatFlags.length > 0 ? data.threatFlags.join(", ") : "None",
          inline: false,
        },
        {
          name: "Device Info",
          value: `${data.device.type} • ${data.device.os} • ${data.device.browser}`,
          inline: true,
        },
        {
          name: "User Agent",
          value: `\`${data.userAgent.substring(0, 120)}\``,
          inline: false,
        },
      ],
      footer: {
        text: "Telegram Mini App - IP & VPN Detection Logger",
      },
      timestamp: new Date().toISOString(),
    };

    // Add stats if available
    if (data.stats) {
      embed.fields.push({
        name: "IP History (24h)",
        value: `Total: ${data.stats.totalAccess} | Suspicious: ${data.stats.suspiciousCount} | VPN: ${data.stats.vpnCount} | Proxy: ${data.stats.proxyCount} | Tor: ${data.stats.torCount}`,
        inline: false,
      });
    }

    const response = await fetch(DISCORD_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ embeds: [embed] }),
    });

    if (!response.ok) {
      console.error("[Discord] Error:", response.statusText);
      return false;
    }
    return true;
  } catch (error) {
    console.error("[Discord] Failed to send:", error);
    return false;
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  detector: router({
    collectData: publicProcedure
      .input(
        z.object({
          ip: z.string().optional(),
          userAgent: z.string().optional(),
          referer: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Get IP from request headers if not provided
        const ip =
          input.ip ||
          (ctx.req.headers["x-forwarded-for"] as string) ||
          (ctx.req.headers["cf-connecting-ip"] as string) ||
          "unknown";

        const userAgent = input.userAgent || (ctx.req.headers["user-agent"] as string) || "unknown";
        const timestamp = new Date().toISOString();

        // Get IP information
        const ipInfoData = await getIPInfo(ip);
        const geoLocation = parseIPInfo(ip, ipInfoData);

        // Detect device
        const device = detectDevice(userAgent);

        // Check for proxy/VPN/Tor
        const proxyData = await checkProxy(ip);
        const { score: threatScore, flags: threatFlags } = calculateThreatScore(proxyData, userAgent, geoLocation.org);

        // Extract threat indicators
        let isVPN = false;
        let isProxy = false;
        let isTor = false;

        if (proxyData) {
          const ipKey = Object.keys(proxyData)[0];
          if (ipKey && proxyData[ipKey]) {
            const details = proxyData[ipKey];
            isVPN = details.vpn === "yes";
            isProxy = details.proxy === "yes";
            isTor = details.tor === "yes";
          }
        }

        // Check if outside Denmark
        const outsideDenmark = isOutsideDenmark(geoLocation.countryCode);

        // Log to database
        await logAccess({
          ip,
          userAgent,
          country: geoLocation.country,
          city: geoLocation.city,
          org: geoLocation.org,
          threatScore,
          threatFlags,
          isVPN,
          isProxy,
          isTor,
          discordSent: false,
        });

        // Get stats for suspicious IPs
        let stats = null;
        let discordSent = false;

        if (threatScore > 60 || outsideDenmark) {
          // This is suspicious or outside Denmark, get stats and send to Discord
          stats = await getAccessStats(ip, 24);

          discordSent = await sendToDiscord({
            ip,
            userAgent,
            device,
            geoLocation,
            threatScore,
            threatFlags,
            timestamp,
            isVPN,
            isProxy,
            isTor,
            outsideDenmark,
            stats: stats || undefined,
          });
        } else {
          // Log clean access to Discord
          discordSent = await sendToDiscord({
            ip,
            userAgent,
            device,
            geoLocation,
            threatScore,
            threatFlags,
            timestamp,
            isVPN,
            isProxy,
            isTor,
            outsideDenmark,
          });
        }

        return {
          success: true,
          discordSent,
          data: {
            ip,
            userAgent,
            device,
            geoLocation,
            threatScore,
            threatFlags,
            timestamp,
            isVPN,
            isProxy,
            isTor,
            outsideDenmark,
          },
        };
      }),

    getStats: publicProcedure
      .input(
        z.object({
          ip: z.string(),
          hours: z.number().optional(),
        })
      )
      .query(async ({ input }) => {
        const stats = await getAccessStats(input.ip, input.hours || 24);
        return stats;
      }),
  }),
});

export type AppRouter = typeof appRouter;
