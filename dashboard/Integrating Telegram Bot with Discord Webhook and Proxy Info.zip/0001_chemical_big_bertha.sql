CREATE TABLE `accessLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ip` varchar(45) NOT NULL,
	`userAgent` text,
	`country` varchar(2),
	`city` varchar(100),
	`org` varchar(255),
	`threatScore` int DEFAULT 0,
	`threatFlags` text,
	`isVPN` int DEFAULT 0,
	`isProxy` int DEFAULT 0,
	`isTor` int DEFAULT 0,
	`discordSent` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `accessLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `rateLimits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ip` varchar(45) NOT NULL,
	`requestCount` int DEFAULT 1,
	`lastRequest` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`isBlocked` int DEFAULT 0,
	`blockedUntil` timestamp,
	CONSTRAINT `rateLimits_id` PRIMARY KEY(`id`),
	CONSTRAINT `rateLimits_ip_unique` UNIQUE(`ip`)
);
