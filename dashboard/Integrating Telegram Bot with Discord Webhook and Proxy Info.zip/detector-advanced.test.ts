import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";
import { appRouter } from "./routers";
import { checkRateLimit, logAccess, getAccessStats } from "./detector-db";
import type { TrpcContext } from "./_core/context";

// Mock fetch for Discord webhook and external APIs
global.fetch = vi.fn();

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createDetectorContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "sample-user",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "x-forwarded-for": "192.168.1.1",
      },
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("Rate Limiting", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should allow first request from new IP", async () => {
    const result = await checkRateLimit("10.0.0.1");
    expect(result.allowed).toBe(true);
    expect(result.remaining).toBe(9); // 10 - 1 = 9
    expect(result.isBlocked).toBe(false);
  });

  it("should track multiple requests within window", async () => {
    const ip = "10.0.0.2";

    // First request
    let result = await checkRateLimit(ip);
    expect(result.allowed).toBe(true);
    expect(result.remaining).toBe(9);

    // Second request
    result = await checkRateLimit(ip);
    expect(result.allowed).toBe(true);
    expect(result.remaining).toBe(8);

    // Third request
    result = await checkRateLimit(ip);
    expect(result.allowed).toBe(true);
    expect(result.remaining).toBe(7);
  });

  it("should block IP after exceeding limit", async () => {
    const ip = "10.0.0.3";

    // Make 10 requests (at limit)
    for (let i = 0; i < 10; i++) {
      const result = await checkRateLimit(ip);
      expect(result.allowed).toBe(true);
    }

    // 11th request should be blocked
    const result = await checkRateLimit(ip);
    expect(result.allowed).toBe(false);
    expect(result.isBlocked).toBe(true);
    expect(result.blockedUntil).toBeDefined();
  });

  it("should return blocked status for blocked IP", async () => {
    const ip = "10.0.0.4";

    // Exceed limit
    for (let i = 0; i < 11; i++) {
      await checkRateLimit(ip);
    }

    // Check status
    const result = await checkRateLimit(ip);
    expect(result.allowed).toBe(false);
    expect(result.isBlocked).toBe(true);
    expect(result.remaining).toBe(0);
  });
});

describe("Database Logging", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should log access to database", async () => {
    const result = await logAccess({
      ip: "1.2.3.4",
      userAgent: "Mozilla/5.0",
      country: "US",
      city: "New York",
      org: "Example ISP",
      threatScore: 25,
      threatFlags: ["Test Flag"],
      isVPN: false,
      isProxy: false,
      isTor: false,
      discordSent: true,
    });

    expect(result).toBeDefined();
  });

  it("should get access statistics", async () => {
    // Log multiple accesses
    await logAccess({
      ip: "5.6.7.8",
      userAgent: "Mozilla/5.0",
      country: "US",
      city: "New York",
      org: "Example ISP",
      threatScore: 75,
      threatFlags: ["VPN Detected"],
      isVPN: true,
      isProxy: false,
      isTor: false,
      discordSent: true,
    });

    await logAccess({
      ip: "5.6.7.8",
      userAgent: "Mozilla/5.0",
      country: "US",
      city: "New York",
      org: "Example ISP",
      threatScore: 45,
      threatFlags: [],
      isVPN: false,
      isProxy: false,
      isTor: false,
      discordSent: true,
    });

    // Get stats
    const stats = await getAccessStats("5.6.7.8", 24);
    expect(stats).toBeDefined();
    if (stats) {
      expect(stats.totalAccess).toBeGreaterThanOrEqual(2);
      expect(stats.vpnCount).toBeGreaterThanOrEqual(1);
    }
  });
});

describe("detector.collectData with rate limiting", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should reject request when rate limited", async () => {
    const ctx = createDetectorContext();
    const caller = appRouter.createCaller(ctx);

    // Mock APIs
    (global.fetch as any).mockImplementation((url: string) => {
      if (url.includes("ipinfo.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              org: "Example ISP",
              country: "US",
              city: "New York",
            }),
        });
      }
      if (url.includes("proxycheck.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              "192.168.1.1": {
                proxy: "no",
                vpn: "no",
                tor: "no",
                risk: 0,
              },
            }),
        });
      }
      if (url.includes("discord.com")) {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({}),
        });
      }
      return Promise.reject(new Error("Unknown URL"));
    });

    // Make requests until rate limited
    let lastResult: any;
    for (let i = 0; i < 15; i++) {
      lastResult = await caller.detector.collectData({
        ip: "192.168.1.1",
        userAgent: "Mozilla/5.0",
      });

      if (!lastResult.success) {
        break;
      }
    }

    // Should eventually be rate limited
    expect(lastResult.rateLimited).toBe(true);
    expect(lastResult.error).toBe("Rate limit exceeded");
  });

  it("should include rate limit info in response", async () => {
    const ctx = createDetectorContext();
    const caller = appRouter.createCaller(ctx);

    (global.fetch as any).mockImplementation((url: string) => {
      if (url.includes("ipinfo.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              org: "Example ISP",
              country: "US",
              city: "New York",
            }),
        });
      }
      if (url.includes("proxycheck.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              "9.9.9.9": {
                proxy: "no",
                vpn: "no",
                tor: "no",
                risk: 0,
              },
            }),
        });
      }
      if (url.includes("discord.com")) {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({}),
        });
      }
      return Promise.reject(new Error("Unknown URL"));
    });

    const result = await caller.detector.collectData({
      ip: "9.9.9.9",
      userAgent: "Mozilla/5.0",
    });

    expect(result.success).toBe(true);
    expect(result.data?.remaining).toBeDefined();
    expect(result.data?.resetAt).toBeDefined();
  });

  it("should send enhanced Discord alert for suspicious activity", async () => {
    const ctx = createDetectorContext();
    const caller = appRouter.createCaller(ctx);

    let discordPayload: any;

    (global.fetch as any).mockImplementation((url: string) => {
      if (url.includes("ipinfo.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              org: "ProtonVPN",
              country: "CH",
              city: "Zurich",
            }),
        });
      }
      if (url.includes("proxycheck.io")) {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({
              "11.11.11.11": {
                proxy: "no",
                vpn: "yes",
                tor: "no",
                risk: 75,
              },
            }),
        });
      }
      if (url.includes("discord.com")) {
        return Promise.resolve({
          ok: true,
          json: async function () {
            const body = this.body;
            discordPayload = JSON.parse(body);
            return {};
          },
        });
      }
      return Promise.reject(new Error("Unknown URL"));
    });

    const result = await caller.detector.collectData({
      ip: "11.11.11.11",
      userAgent: "Mozilla/5.0",
    });

    expect(result.success).toBe(true);
    expect(result.data?.threatScore).toBeGreaterThan(60);
    expect(result.discordSent).toBe(true);
  });
});

describe("detector.getStats", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should retrieve access statistics", async () => {
    const ctx = createDetectorContext();
    const caller = appRouter.createCaller(ctx);

    // Log some access data first
    await logAccess({
      ip: "20.20.20.20",
      userAgent: "Mozilla/5.0",
      country: "US",
      city: "New York",
      org: "Example ISP",
      threatScore: 50,
      threatFlags: [],
      isVPN: false,
      isProxy: false,
      isTor: false,
      discordSent: false,
    });

    // Get stats
    const stats = await caller.detector.getStats({
      ip: "20.20.20.20",
      hours: 24,
    });

    expect(stats).toBeDefined();
    if (stats) {
      expect(stats.totalAccess).toBeGreaterThanOrEqual(1);
    }
  });
});
