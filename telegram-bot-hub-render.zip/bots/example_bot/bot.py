
# Example Telegram bot

import os
from telegram.ext import ApplicationBuilder, CommandHandler

TOKEN = os.environ.get("EXAMPLE_BOT_TOKEN")

async def start(update, context):
    await update.message.reply_text("Example bot works")

def main():
    if not TOKEN:
        print("EXAMPLE_BOT_TOKEN missing")
        return

    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))

    print("Example bot running")
    app.run_polling()

if __name__ == "__main__":
    main()
