
# Telegram Bot Hub (Render Ready)

Deploy multiple Telegram bots on **one Render free service**.

## Features
- Bot auto-discovery (`/bots` folder)
- Auto restart if a bot crashes
- Admin control bot
- Simple dashboard + health endpoint
- Ready for UptimeRobot keep-alive
- 1-click Render deploy

## Deploy

1. Create a GitHub repo
2. Upload all files
3. Go to https://dashboard.render.com
4. New → Web Service → connect repo
5. Render will detect `render.yaml`

## Environment variables (Render)

ADMIN_BOT_TOKEN=your_admin_bot_token

Each bot can read its own token via environment variables.

## UptimeRobot

Monitor:

https://YOUR-RENDER-URL.onrender.com/health

Interval: 5 minutes
