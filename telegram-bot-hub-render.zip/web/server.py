
from flask import Flask
import threading

from core.bot_manager import start_all, monitor
from control.admin_bot import start_admin

app = Flask(__name__)

@app.route("/")
def home():
    return "Telegram Bot Hub Running"

@app.route("/health")
def health():
    return "OK"

def system():
    start_all()
    monitor()

if __name__ == "__main__":
    threading.Thread(target=system).start()
    threading.Thread(target=start_admin).start()

    app.run(host="0.0.0.0", port=10000)
