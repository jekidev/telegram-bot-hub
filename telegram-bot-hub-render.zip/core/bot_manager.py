
import subprocess
import time
from core.auto_discovery import discover_bots

processes = {}

def start_all():
    bots = discover_bots()
    for bot in bots:
        print("Starting", bot)
        processes[bot] = subprocess.Popen(["python", bot])

def monitor():
    while True:
        for bot, proc in list(processes.items()):
            if proc.poll() is not None:
                print("Restarting", bot)
                processes[bot] = subprocess.Popen(["python", bot])
        time.sleep(10)
