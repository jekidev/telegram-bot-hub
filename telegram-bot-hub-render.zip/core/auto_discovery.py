
import os

def discover_bots():
    bots = []
    root = "bots"
    if not os.path.exists(root):
        return bots

    for folder in os.listdir(root):
        path = os.path.join(root, folder)
        if os.path.isdir(path):
            for file in os.listdir(path):
                if file.endswith(".py"):
                    bots.append(os.path.join(path, file))
    return bots
