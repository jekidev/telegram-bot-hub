
import os
from telegram.ext import ApplicationBuilder, CommandHandler

TOKEN = os.environ.get("ADMIN_BOT_TOKEN")

async def start(update, context):
    await update.message.reply_text("Bot Hub Admin Ready")

async def status(update, context):
    await update.message.reply_text("Bots running (check logs on Render)")

def start_admin():
    if not TOKEN:
        print("ADMIN_BOT_TOKEN missing")
        return

    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))

    print("Admin bot running")
    app.run_polling()
